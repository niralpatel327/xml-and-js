# Activity

- Convert `people.json` into xml file
- Create html file
- Dynamically load data from `people.xml` into table
- Display full name for each person
